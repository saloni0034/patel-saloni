from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages
from django.http import HttpResponseRedirect

# Create your views here.
def index(request):
    try:
        uid = request.session['logid']
        if uid is None:
            return render(request,'login.html')
        else:
            return render(request,'index.html')
    except:
        pass
    return render(request,'index.html')

def about(request):
    return render(request,'about.html')

def wishlistpage(request):
    return render(request, 'wishlist.html')

def contact(request):
    return render(request,'contact.html')

def services(request):
    return render(request,'services.html')

def login(request):
    return render(request,'login.html')

def register (request):
    return render(request,'Register.html')

def add(request, id):
    uid = request.session['logid']
    query = Wishlist(login_Id=userregister(id=uid), college_Id=colleges(id=id))
    query.save()
    return render(request, 'index.html')

def fetchdata(request):
    if request.method =='POST':
        name=request.POST.get('uname')
        email = request.POST.get('uemail')
        phone = request.POST.get('uphone')
        password = request.POST.get('password')
        query = userregister(name=name,email=email,phone=phone,password=password)
        query.save()
    else:
        pass
    return render(request,'Register.html')

def fetchlogindata(request):
    if request.method=="POST":
        uemail= request.POST.get('uemail')
        upassword = request.POST.get('upass')
        try:
            checkuser = userregister.objects.get(email=uemail,password=upassword)
            request.session['logid']=checkuser.id
            request.session['logname']=checkuser.name
            request.session.save()
        except:
            checkuser = None

        if checkuser is not None:
            return render(request,'index.html')
        else:
            messages.error(request,"Invalid email or password!")
            return render(request,'login.html')
    else:
        pass
    return render(request,'login.html')

def logout(request):
    try:
        del request.session['logid']
        del request.session['logname']
    except:
        pass
    return render(request,"login.html")

def college(request):
    getdata = colleges.objects.all()
    country = countries.objects.all()
    streams = stream.objects.all()
    return render(request,"college.html",locals())

def get_states(request):
    country_id = request.GET['country_id']
    get_country = countries.objects.get(id=country_id)
    state = states.objects.filter(country_Id=get_country)
    return render(request, 'get-states.html', locals())

def get_cities(request):
    state_id = request.GET['state_id']
    get_state = states.objects.get(id=state_id)
    city = cities.objects.filter(state_Id=get_state)
    return render(request, 'get-cities.html', locals())

def get_substream(request):
    course_id = request.GET['course_id']
    get_stream = stream.objects.get(id=course_id)
    course = courses.objects.filter(stream_Id=get_stream)
    print(course)
    return render(request, 'get-substream.html', locals())

def marks(request):
    uid = request.session['logid']

    getmarks1 = usermarks.objects.filter(login_Id=uid)
    if not getmarks1:
        marks1 = None
    else:
        getmarks = usermarks.objects.get(login_Id=uid)
        marks1 = getmarks

    print(marks)
    return render(request, 'Marks.html', {'marks1': marks1})

def insertmarks(request):
    if request.method == 'POST':

        lid = request.session["logid"]
        total = request.POST.get("marks")
        percentile = request.POST.get("percentile")

        marks1 = usermarks(Total=total, Percentage=percentile, login_Id=userregister(id=lid))
        marks1.save()
        return redirect('colleges')
    else:
        messages.error(request, 'error occured')

    return render(request, 'college.html')

def updatemarks(request):
    if request.method == 'POST':

        lid = request.session["logid"]
        total = request.POST.get("marks")
        percentile = request.POST.get("percentile")

        obj = usermarks.objects.get(login_Id=lid)
        obj.Total = total
        obj.Percentage = percentile
        obj.save()
        messages.info(request, 'Marks Updated')
        return redirect('colleges')
    else:
        messages.error(request, 'error occured')

    return render(request, 'colleges')

def search(request):
    country = countries.objects.all()
    streams = stream.objects.all()
    if request.method == 'POST':
        check = request.POST.get("check")
        selectcountry = request.POST.get("country")
        selectstate = request.POST.get("state")
        selectcity = request.POST.get("city")
        selectcourse = request.POST.get("course")
        selectsubcourse = request.POST.get("substream")
        if check:
            uid = request.session['logid']
            print(uid)

            fetchmarks = usermarks.objects.filter(login_Id=uid).first()
            if fetchmarks is None:
                messages.error(request, "First Insert Your Marks to Continue")
                return redirect('college')
            else:
                percentile = fetchmarks.Percentage
                fetchcolleges = merit.objects.values('college_Id').filter(cutoff__lte=percentile)
                getcourse = courses.objects.filter(coursename=selectsubcourse).values('college_Id')
                getdata = colleges.objects.filter(country_Id=selectcountry, state_Id=selectstate,city_Id=selectcity).values('id')
                common1 = getdata.intersection(getcourse)
                common = common1.intersection(fetchcolleges)
                cdetails = colleges.objects.filter(id__in=common)
                print(getcourse)
                show = "no"
                return render(request, 'college.html', locals())
        else:
            getcourse = courses.objects.filter(coursename=selectsubcourse).values('college_Id')
            getdata = colleges.objects.filter(country_Id=selectcountry, state_Id=selectstate, city_Id=selectcity).values('id')
            common = getdata.intersection(getcourse)
            cdetails = colleges.objects.filter(id__in=common)
            print(getcourse)
            show="no"
            return render(request, 'college.html', locals())
    else:
        return redirect('college')


def insertfeedback(request):
    if request.method == 'POST':
        uid = request.session['logid']

        name = request.POST.get("name")
        email = request.POST.get("email")
        msg = request.POST.get("msg")
        query = Feedback(login_Id=userregister(id=uid), name=name, email=email , Comment=msg)
        query.save()
        messages.info(request, "Feedback Recorded Successfully")
        return redirect('contact')
    else:
        messages.error(request, 'Error occured')

    return render(request, 'contact.html')

def viewcollege(request, id):
    getdata = colleges.objects.get(id=id)
    fetchcourses = courses.objects.all().filter(college_Id=id)
    getreviews = Review.objects.all().filter(college_Id=id)
    return render(request, 'viewcollege.html', {'college': getdata, 'courses': fetchcourses,'review': getreviews, 'id': id})



def insertreview(request, id):
    if request.method == 'POST':
        uid = request.session['logid']
        cmnt = request.POST.get("comment")
        rtng = request.POST.get("rating")

        query = Review(login_Id=userregister(id=uid), Comment=cmnt, rating=rtng, college_Id=colleges(id=id))
        query.save()
        messages.info(request, "Review Inserted Successfully")
        return redirect('viewcollege.html', id=id)

    else:
        messages.error(request, 'Error occured')

    return render(request, 'viewcollege.html')

def viewlist(request):
    uid = request.session['logid']
    print(uid)
    fetchwishlist = Wishlist.objects.values('college_Id').filter(login_Id=uid)
    print(fetchwishlist)
    collegedata = colleges.objects.filter(id__in=fetchwishlist).values()
    print(collegedata)
    return render(request, 'wishlist.html', {'list':collegedata})

def delete(request,id):
    getdetails = Wishlist.objects.get(college_Id=colleges(id=id))
    print(getdetails)
    getdetails.delete()
    return redirect(viewlist)

def fpage(request):
    return render(request,"forgot.html")

def forgotpassword(request):
    if request.method == 'POST':
        username = request.POST['email']
        try:
            user = userregister.objects.get(email=username)

        except login.DoesNotExist:
            user = None
        #if user exist then only below condition will run otherwise it will give error as described in else condition.
        if user is not None:
            #################### Password Generation ##########################
            import random
            letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
                       't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
                       'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
            numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

            nr_letters = 6
            nr_symbols = 1
            nr_numbers = 3
            password_list = []

            for char in range(1, nr_letters + 1):
                password_list.append(random.choice(letters))

            for char in range(1, nr_symbols + 1):
                password_list += random.choice(symbols)

            for char in range(1, nr_numbers + 1):
                password_list += random.choice(numbers)

            print(password_list)
            random.shuffle(password_list)
            print(password_list)

            password = ""  #we will get final password in this var.
            for char in password_list:
                password += char

            ##############################################################


            msg = "hello here it is your new password  "+password   #this variable will be passed as message in mail

            ############ code for sending mail ########################

            from django.core.mail import send_mail

            send_mail(
                'Your New Password',
                msg,
                'krushanuinfolabz@gmail.com',
                [username],
                fail_silently=False,
            )
            # NOTE: must include below details in settings.py
            # detail tutorial - https://www.geeksforgeeks.org/setup-sending-email-in-django-project/
            # EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
            # EMAIL_HOST = 'smtp.gmail.com'
            # EMAIL_USE_TLS = True
            # EMAIL_PORT = 587
            # EMAIL_HOST_USER = 'mail from which email will be sent'
            # EMAIL_HOST_PASSWORD = 'pjobvjckluqrtpkl'   #turn on 2 step verification and then generate app password which will be 16 digit code and past it here

            #############################################

            #now update the password in model
            cuser = userregister.objects.get(email=username)
            cuser.password = password
            cuser.save(update_fields=['password'])

            print('Mail sent')
            messages.info(request, 'mail is sent')
            return redirect(login)

        else:
            messages.info(request, 'This account does not exist')
    return redirect(index)


def a(request):
    country = countries.objects.all()
    streams = stream.objects.all()
    getcourse = courses.objects.filter(coursename = "B.Sc").values('college_Id')
    print(getcourse)
    cdetails = colleges.objects.filter(id__in=getcourse)
    return render(request, 'college.html', locals())
def b(request):
    country = countries.objects.all()
    streams = stream.objects.all()
    getcourse = courses.objects.filter(coursename = "B.Tech").values('college_Id')
    print(getcourse)
    cdetails = colleges.objects.filter(id__in=getcourse)
    return render(request, 'college.html', locals())
def c(request):
    country = countries.objects.all()
    streams = stream.objects.all()
    getcourse = courses.objects.filter(coursename = "BCA").values('college_Id')
    cdetails = colleges.objects.filter(id__in=getcourse)
    return render(request, 'college.html', locals())
def d(request):
    country = countries.objects.all()
    streams = stream.objects.all()
    getcourse = courses.objects.filter(coursename = "BBA").values('college_Id')
    cdetails = colleges.objects.filter(id__in=getcourse)
    return render(request, 'college.html', locals())
def e(request):
    country = countries.objects.all()
    streams = stream.objects.all()
    getcourse = courses.objects.filter(coursename = "B.Com").values('college_Id')
    cdetails = colleges.objects.filter(id__in=getcourse)
    return render(request, 'college.html', locals())
def f(request):
    country = countries.objects.all()
    streams = stream.objects.all()
    getcourse = courses.objects.filter(coursename = "B.Ed").values('college_Id')
    cdetails = colleges.objects.filter(id__in=getcourse)
    return render(request, 'college.html', locals())




