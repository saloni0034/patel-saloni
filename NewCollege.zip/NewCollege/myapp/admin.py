from django.contrib import admin
from .models import *

# Register your models here.
class showCountries(admin.ModelAdmin):
    list_display = ['countryname']
class showState(admin.ModelAdmin):
    list_display = ['statename','country_Id']
class showCities(admin.ModelAdmin):
    list_display = ['cityname','state_Id','country_Id']

class showStream(admin.ModelAdmin):
    list_display = ['streamname']

class showCourses(admin.ModelAdmin):
    list_display = ['coursename','college_Id']

class showCollege(admin.ModelAdmin):
    list_display = ['admin_photo','collegename','contact']

class showregistertable(admin.ModelAdmin):
    list_display = ['name','email']

class showMerit(admin.ModelAdmin):
    list_display = ['college_Id','cutoff','course_Id']

class showFeedback(admin.ModelAdmin):
    list_display = ['login_Id','name']

class showMarks(admin.ModelAdmin):
    list_display = ['login_Id','Percentage']

class showReview(admin.ModelAdmin):
    list_display = ['rating','college_Id']

admin.site.register(countries,showCountries)
admin.site.register(states,showState)
admin.site.register(cities,showCities)
admin.site.register(courses,showCourses)
admin.site.register(stream,showStream)
admin.site.register(colleges,showCollege)
admin.site.register(userregister,showregistertable)
admin.site.register(merit,showMerit)
admin.site.register(Feedback,showFeedback)
admin.site.register(usermarks,showMarks)
admin.site.register(Review,showReview)




