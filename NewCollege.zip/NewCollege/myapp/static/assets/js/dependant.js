$(document).ready(function() {
    $("#country").change(function() {
        var country_id = $(this).val();
        var url = "/get-states/?country_id="+country_id;
        $.get(url, function(data, status){
            $("#state").html(data);
        });
    });
});
$(document).ready(function() {
    $("#state").change(function() {
        var state_id = $(this).val();
        var url = "/get-cities/?state_id="+state_id;
        $.get(url, function(data, status){
            $("#city").html(data);
        });
    });
});
$(document).ready(function() {
    $("#course").change(function() {
        var course_id = $(this).val();
        var url = "/get-substream/?course_id="+course_id;
        $.get(url, function(data, status){
            $("#substream").html(data);
        });
    });
});

$(document).ready(function() {
    $("#course").change(function() {
        var course_id = $(this).val();
        var url = "/get-substream/?course_id="+course_id;
        $.get(url, function(data, status){
            $("#substream").html(data);
        });
    });
});

