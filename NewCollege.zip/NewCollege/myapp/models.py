from django.db import models
from django.utils.safestring import mark_safe
# Create your models here.

class userregister(models.Model):
    name = models.CharField(max_length=25)
    email = models.EmailField()
    phone = models.BigIntegerField()
    password = models.CharField(max_length=30)

    def __str__(self):
        return self.name

class countries(models.Model):
    countryname = models.CharField(max_length=60)

    def __str__(self):
        return self.countryname

class states(models.Model):
    country_Id = models.ForeignKey(countries, on_delete=models.CASCADE)
    statename = models.CharField(max_length=30)

    def __str__(self):
        return self.statename

class cities(models.Model):
    cityname = models.CharField(max_length=30)
    state_Id = models.ForeignKey(states, on_delete=models.CASCADE)
    country_Id = models.ForeignKey(countries, on_delete=models.CASCADE)

    def __str__(self):
        return self.cityname

class colleges(models.Model):
    collegename = models.CharField(max_length=100)
    country_Id = models.ForeignKey(countries, on_delete=models.CASCADE)
    state_Id = models.ForeignKey(states, on_delete=models.CASCADE)
    city_Id = models.ForeignKey(cities, on_delete=models.CASCADE)
    email = models.EmailField()
    contact = models.BigIntegerField()
    address = models.TextField()
    website = models.CharField(max_length=100)
    map = models.TextField()
    image = models.ImageField(upload_to='photos', null = True)

    def admin_photo(self):
        return mark_safe('<img src="{}" width="100"/>'.format(self.image.url))

    admin_photo.allow_tags = True

    def __str__(self):
        return self.collegename

class stream(models.Model):
    streamname = models.CharField(max_length=20)

    def __str__(self):
        return self.streamname

class courses(models.Model):
    stream_Id = models.ForeignKey(stream, on_delete=models.CASCADE, null = True)
    coursename = models.CharField(max_length=20)
    coursefee = models.IntegerField()
    college_Id = models.ForeignKey(colleges, on_delete=models.CASCADE)

    def __str__(self):
        return self.coursename

class merit(models.Model):
    college_Id = models.ForeignKey(colleges, on_delete=models.CASCADE)
    course_Id = models.ForeignKey(courses, on_delete=models.CASCADE)
    cutoff = models.IntegerField()

    def __int__(self):
        return self.CutOff

class usermarks(models.Model):
    login_Id = models.ForeignKey(userregister, on_delete=models.CASCADE)
    Total = models.IntegerField()
    Percentage = models.IntegerField()

class Wishlist(models.Model):
    login_Id = models.ForeignKey(userregister, on_delete=models.CASCADE)
    college_Id = models.ForeignKey(colleges, on_delete=models.CASCADE)
    DateTime = models.DateTimeField(auto_now_add=True)

class Feedback(models.Model):
    DateTime = models.DateTimeField(auto_now_add=True)
    login_Id = models.ForeignKey(userregister, on_delete=models.CASCADE)
    name = models.CharField(max_length=40)
    email = models.EmailField()
    Comment = models.TextField()

class Review(models.Model):
    login_Id = models.ForeignKey(userregister, on_delete=models.CASCADE)
    Comment = models.CharField(max_length=500)
    rating = models.IntegerField()
    college_Id = models.ForeignKey(colleges, on_delete=models.CASCADE)
